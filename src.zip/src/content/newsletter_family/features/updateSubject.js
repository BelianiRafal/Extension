const updateSubject = {
  init(ui) {
    const updateSubject = ui.createTh({ title: "Update subject" });
    ui.header.append(updateSubject)
  },
};
