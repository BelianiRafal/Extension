const updateBody = {
  body: null,

  init(ui) {
    this.body = document.querySelector("textarea[name=body]");
    if (!this.body) {
      return;
    }
    const updateBody = ui.createTh({
      title: "Update body",
      description: "Copy body content from current campaign.",
    });
    ui.header.append(updateBody);
    const rows = ui.tbody.querySelectorAll("tr");
    rows.forEach((row) => {
      const id = row.querySelector("a");
      if (!id) {
        new Notification("Newsletter Id page not found.");
        return;
      }
      const _id = id.textContent.trim();

      const button = ui.createButton({
        title: "Copy body",
        onClick: () => {
          if (this.body.value.trim().length <= 10) {
            new Notification("Body content too small.");
            return;
          }
          const payload = {
            campaign_id: _id,
            body: this.body.value,
          };
          handleButtonBodyUpdate(payload);
        },
      });
      row.append(ui.createColumn([button]));
    });
  },
};
