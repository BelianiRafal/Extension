



const copyCampaign = {

    init(ui) {
        const copy = ui.createTh({ title: "Copy campaign id" });
        ui.header.append(copy)
    }

}