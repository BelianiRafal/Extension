(function (global, factory) {
  typeof exports === "object" && typeof module !== "undefined"
    ? (module.exports = factory())
    : typeof define === "function" && define.amd
    ? define(factory)
    : ((global = global || self), (global.Mustache = factory()));
})(this, function () {
  "use strict";

  /*!
   * mustache.js - Logic-less {{mustache}} templates with JavaScript
   * http://github.com/janl/mustache.js
   */

  var objectToString = Object.prototype.toString;
  var isArray =
    Array.isArray ||
    function isArrayPolyfill(object) {
      return objectToString.call(object) === "[object Array]";
    };

  function isFunction(object) {
    return typeof object === "function";
  }

  /**
   * More correct typeof string handling array
   * which normally returns typeof 'object'
   */
  function typeStr(obj) {
    return isArray(obj) ? "array" : typeof obj;
  }

  function escapeRegExp(string) {
    return string.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&");
  }

  /**
   * Null safe way of checking whether or not an object,
   * including its prototype, has a given property
   */
  function hasProperty(obj, propName) {
    return obj != null && typeof obj === "object" && propName in obj;
  }

  /**
   * Safe way of detecting whether or not the given thing is a primitive and
   * whether it has the given property
   */
  function primitiveHasOwnProperty(primitive, propName) {
    return (
      primitive != null &&
      typeof primitive !== "object" &&
      primitive.hasOwnProperty &&
      primitive.hasOwnProperty(propName)
    );
  }

  // Workaround for https://issues.apache.org/jira/browse/COUCHDB-577
  // See https://github.com/janl/mustache.js/issues/189
  var regExpTest = RegExp.prototype.test;
  function testRegExp(re, string) {
    return regExpTest.call(re, string);
  }

  var nonSpaceRe = /\S/;
  function isWhitespace(string) {
    return !testRegExp(nonSpaceRe, string);
  }

  var entityMap = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
    "/": "&#x2F;",
    "`": "&#x60;",
    "=": "&#x3D;",
  };

  function escapeHtml(string) {
    return String(string).replace(/[&<>"'`=\/]/g, function fromEntityMap(s) {
      return entityMap[s];
    });
  }

  var whiteRe = /\s*/;
  var spaceRe = /\s+/;
  var equalsRe = /\s*=/;
  var curlyRe = /\s*\}/;
  var tagRe = /#|\^|\/|>|\{|&|=|!/;

  /**
   * Breaks up the given `template` string into a tree of tokens. If the `tags`
   * argument is given here it must be an array with two string values: the
   * opening and closing tags used in the template (e.g. [ "<%", "%>" ]). Of
   * course, the default is to use mustaches (i.e. mustache.tags).
   *
   * A token is an array with at least 4 elements. The first element is the
   * mustache symbol that was used inside the tag, e.g. "#" or "&". If the tag
   * did not contain a symbol (i.e. {{myValue}}) this element is "name". For
   * all text that appears outside a symbol this element is "text".
   *
   * The second element of a token is its "value". For mustache tags this is
   * whatever else was inside the tag besides the opening symbol. For text tokens
   * this is the text itself.
   *
   * The third and fourth elements of the token are the start and end indices,
   * respectively, of the token in the original template.
   *
   * Tokens that are the root node of a subtree contain two more elements: 1) an
   * array of tokens in the subtree and 2) the index in the original template at
   * which the closing tag for that section begins.
   *
   * Tokens for partials also contain two more elements: 1) a string value of
   * indendation prior to that tag and 2) the index of that tag on that line -
   * eg a value of 2 indicates the partial is the third tag on this line.
   */
  function parseTemplate(template, tags) {
    if (!template) return [];
    var lineHasNonSpace = false;
    var sections = []; // Stack to hold section tokens
    var tokens = []; // Buffer to hold the tokens
    var spaces = []; // Indices of whitespace tokens on the current line
    var hasTag = false; // Is there a {{tag}} on the current line?
    var nonSpace = false; // Is there a non-space char on the current line?
    var indentation = ""; // Tracks indentation for tags that use it
    var tagIndex = 0; // Stores a count of number of tags encountered on a line

    // Strips all whitespace tokens array for the current line
    // if there was a {{#tag}} on it and otherwise only space.
    function stripSpace() {
      if (hasTag && !nonSpace) {
        while (spaces.length) delete tokens[spaces.pop()];
      } else {
        spaces = [];
      }

      hasTag = false;
      nonSpace = false;
    }

    var openingTagRe, closingTagRe, closingCurlyRe;
    function compileTags(tagsToCompile) {
      if (typeof tagsToCompile === "string")
        tagsToCompile = tagsToCompile.split(spaceRe, 2);

      if (!isArray(tagsToCompile) || tagsToCompile.length !== 2)
        throw new Error("Invalid tags: " + tagsToCompile);

      openingTagRe = new RegExp(escapeRegExp(tagsToCompile[0]) + "\\s*");
      closingTagRe = new RegExp("\\s*" + escapeRegExp(tagsToCompile[1]));
      closingCurlyRe = new RegExp(
        "\\s*" + escapeRegExp("}" + tagsToCompile[1])
      );
    }

    compileTags(tags || mustache.tags);

    var scanner = new Scanner(template);

    var start, type, value, chr, token, openSection;
    while (!scanner.eos()) {
      start = scanner.pos;

      // Match any text between tags.
      value = scanner.scanUntil(openingTagRe);

      if (value) {
        for (var i = 0, valueLength = value.length; i < valueLength; ++i) {
          chr = value.charAt(i);

          if (isWhitespace(chr)) {
            spaces.push(tokens.length);
            indentation += chr;
          } else {
            nonSpace = true;
            lineHasNonSpace = true;
            indentation += " ";
          }

          tokens.push(["text", chr, start, start + 1]);
          start += 1;

          // Check for whitespace on the current line.
          if (chr === "\n") {
            stripSpace();
            indentation = "";
            tagIndex = 0;
            lineHasNonSpace = false;
          }
        }
      }

      // Match the opening tag.
      if (!scanner.scan(openingTagRe)) break;

      hasTag = true;

      // Get the tag type.
      type = scanner.scan(tagRe) || "name";
      scanner.scan(whiteRe);

      // Get the tag value.
      if (type === "=") {
        value = scanner.scanUntil(equalsRe);
        scanner.scan(equalsRe);
        scanner.scanUntil(closingTagRe);
      } else if (type === "{") {
        value = scanner.scanUntil(closingCurlyRe);
        scanner.scan(curlyRe);
        scanner.scanUntil(closingTagRe);
        type = "&";
      } else {
        value = scanner.scanUntil(closingTagRe);
      }

      // Match the closing tag.
      if (!scanner.scan(closingTagRe))
        throw new Error("Unclosed tag at " + scanner.pos);

      if (type == ">") {
        token = [
          type,
          value,
          start,
          scanner.pos,
          indentation,
          tagIndex,
          lineHasNonSpace,
        ];
      } else {
        token = [type, value, start, scanner.pos];
      }
      tagIndex++;
      tokens.push(token);

      if (type === "#" || type === "^") {
        sections.push(token);
      } else if (type === "/") {
        // Check section nesting.
        openSection = sections.pop();

        if (!openSection)
          throw new Error('Unopened section "' + value + '" at ' + start);

        if (openSection[1] !== value)
          throw new Error(
            'Unclosed section "' + openSection[1] + '" at ' + start
          );
      } else if (type === "name" || type === "{" || type === "&") {
        nonSpace = true;
      } else if (type === "=") {
        // Set the tags for the next time around.
        compileTags(value);
      }
    }

    stripSpace();

    // Make sure there are no open sections when we're done.
    openSection = sections.pop();

    if (openSection)
      throw new Error(
        'Unclosed section "' + openSection[1] + '" at ' + scanner.pos
      );

    return nestTokens(squashTokens(tokens));
  }

  /**
   * Combines the values of consecutive text tokens in the given `tokens` array
   * to a single token.
   */
  function squashTokens(tokens) {
    var squashedTokens = [];

    var token, lastToken;
    for (var i = 0, numTokens = tokens.length; i < numTokens; ++i) {
      token = tokens[i];

      if (token) {
        if (token[0] === "text" && lastToken && lastToken[0] === "text") {
          lastToken[1] += token[1];
          lastToken[3] = token[3];
        } else {
          squashedTokens.push(token);
          lastToken = token;
        }
      }
    }

    return squashedTokens;
  }

  /**
   * Forms the given array of `tokens` into a nested tree structure where
   * tokens that represent a section have two additional items: 1) an array of
   * all tokens that appear in that section and 2) the index in the original
   * template that represents the end of that section.
   */
  function nestTokens(tokens) {
    var nestedTokens = [];
    var collector = nestedTokens;
    var sections = [];

    var token, section;
    for (var i = 0, numTokens = tokens.length; i < numTokens; ++i) {
      token = tokens[i];

      switch (token[0]) {
        case "#":
        case "^":
          collector.push(token);
          sections.push(token);
          collector = token[4] = [];
          break;
        case "/":
          section = sections.pop();
          section[5] = token[2];
          collector =
            sections.length > 0
              ? sections[sections.length - 1][4]
              : nestedTokens;
          break;
        default:
          collector.push(token);
      }
    }

    return nestedTokens;
  }

  /**
   * A simple string scanner that is used by the template parser to find
   * tokens in template strings.
   */
  function Scanner(string) {
    this.string = string;
    this.tail = string;
    this.pos = 0;
  }

  /**
   * Returns `true` if the tail is empty (end of string).
   */
  Scanner.prototype.eos = function eos() {
    return this.tail === "";
  };

  /**
   * Tries to match the given regular expression at the current position.
   * Returns the matched text if it can match, the empty string otherwise.
   */
  Scanner.prototype.scan = function scan(re) {
    var match = this.tail.match(re);

    if (!match || match.index !== 0) return "";

    var string = match[0];

    this.tail = this.tail.substring(string.length);
    this.pos += string.length;

    return string;
  };

  /**
   * Skips all text until the given regular expression can be matched. Returns
   * the skipped string, which is the entire tail if no match can be made.
   */
  Scanner.prototype.scanUntil = function scanUntil(re) {
    var index = this.tail.search(re),
      match;

    switch (index) {
      case -1:
        match = this.tail;
        this.tail = "";
        break;
      case 0:
        match = "";
        break;
      default:
        match = this.tail.substring(0, index);
        this.tail = this.tail.substring(index);
    }

    this.pos += match.length;

    return match;
  };

  /**
   * Represents a rendering context by wrapping a view object and
   * maintaining a reference to the parent context.
   */
  function Context(view, parentContext) {
    this.view = view;
    this.cache = { ".": this.view };
    this.parent = parentContext;
  }

  /**
   * Creates a new context using the given view with this context
   * as the parent.
   */
  Context.prototype.push = function push(view) {
    return new Context(view, this);
  };

  /**
   * Returns the value of the given name in this context, traversing
   * up the context hierarchy if the value is absent in this context's view.
   */
  Context.prototype.lookup = function lookup(name) {
    var cache = this.cache;

    var value;
    if (cache.hasOwnProperty(name)) {
      value = cache[name];
    } else {
      var context = this,
        intermediateValue,
        names,
        index,
        lookupHit = false;

      while (context) {
        if (name.indexOf(".") > 0) {
          intermediateValue = context.view;
          names = name.split(".");
          index = 0;

          /**
           * Using the dot notion path in `name`, we descend through the
           * nested objects.
           *
           * To be certain that the lookup has been successful, we have to
           * check if the last object in the path actually has the property
           * we are looking for. We store the result in `lookupHit`.
           *
           * This is specially necessary for when the value has been set to
           * `undefined` and we want to avoid looking up parent contexts.
           *
           * In the case where dot notation is used, we consider the lookup
           * to be successful even if the last "object" in the path is
           * not actually an object but a primitive (e.g., a string, or an
           * integer), because it is sometimes useful to access a property
           * of an autoboxed primitive, such as the length of a string.
           **/
          while (intermediateValue != null && index < names.length) {
            if (index === names.length - 1)
              lookupHit =
                hasProperty(intermediateValue, names[index]) ||
                primitiveHasOwnProperty(intermediateValue, names[index]);

            intermediateValue = intermediateValue[names[index++]];
          }
        } else {
          intermediateValue = context.view[name];

          /**
           * Only checking against `hasProperty`, which always returns `false` if
           * `context.view` is not an object. Deliberately omitting the check
           * against `primitiveHasOwnProperty` if dot notation is not used.
           *
           * Consider this example:
           * ```
           * Mustache.render("The length of a football field is {{#length}}{{length}}{{/length}}.", {length: "100 yards"})
           * ```
           *
           * If we were to check also against `primitiveHasOwnProperty`, as we do
           * in the dot notation case, then render call would return:
           *
           * "The length of a football field is 9."
           *
           * rather than the expected:
           *
           * "The length of a football field is 100 yards."
           **/
          lookupHit = hasProperty(context.view, name);
        }

        if (lookupHit) {
          value = intermediateValue;
          break;
        }

        context = context.parent;
      }

      cache[name] = value;
    }

    if (isFunction(value)) value = value.call(this.view);

    return value;
  };

  /**
   * A Writer knows how to take a stream of tokens and render them to a
   * string, given a context. It also maintains a cache of templates to
   * avoid the need to parse the same template twice.
   */
  function Writer() {
    this.templateCache = {
      _cache: {},
      set: function set(key, value) {
        this._cache[key] = value;
      },
      get: function get(key) {
        return this._cache[key];
      },
      clear: function clear() {
        this._cache = {};
      },
    };
  }

  /**
   * Clears all cached templates in this writer.
   */
  Writer.prototype.clearCache = function clearCache() {
    if (typeof this.templateCache !== "undefined") {
      this.templateCache.clear();
    }
  };

  /**
   * Parses and caches the given `template` according to the given `tags` or
   * `mustache.tags` if `tags` is omitted,  and returns the array of tokens
   * that is generated from the parse.
   */
  Writer.prototype.parse = function parse(template, tags) {
    var cache = this.templateCache;
    var cacheKey = template + ":" + (tags || mustache.tags).join(":");
    var isCacheEnabled = typeof cache !== "undefined";
    var tokens = isCacheEnabled ? cache.get(cacheKey) : undefined;

    if (tokens == undefined) {
      tokens = parseTemplate(template, tags);
      isCacheEnabled && cache.set(cacheKey, tokens);
    }
    return tokens;
  };

  /**
   * High-level method that is used to render the given `template` with
   * the given `view`.
   *
   * The optional `partials` argument may be an object that contains the
   * names and templates of partials that are used in the template. It may
   * also be a function that is used to load partial templates on the fly
   * that takes a single argument: the name of the partial.
   *
   * If the optional `config` argument is given here, then it should be an
   * object with a `tags` attribute or an `escape` attribute or both.
   * If an array is passed, then it will be interpreted the same way as
   * a `tags` attribute on a `config` object.
   *
   * The `tags` attribute of a `config` object must be an array with two
   * string values: the opening and closing tags used in the template (e.g.
   * [ "<%", "%>" ]). The default is to mustache.tags.
   *
   * The `escape` attribute of a `config` object must be a function which
   * accepts a string as input and outputs a safely escaped string.
   * If an `escape` function is not provided, then an HTML-safe string
   * escaping function is used as the default.
   */
  Writer.prototype.render = function render(template, view, partials, config) {
    var tags = this.getConfigTags(config);
    var tokens = this.parse(template, tags);
    var context = view instanceof Context ? view : new Context(view, undefined);
    return this.renderTokens(tokens, context, partials, template, config);
  };

  /**
   * Low-level method that renders the given array of `tokens` using
   * the given `context` and `partials`.
   *
   * Note: The `originalTemplate` is only ever used to extract the portion
   * of the original template that was contained in a higher-order section.
   * If the template doesn't use higher-order sections, this argument may
   * be omitted.
   */
  Writer.prototype.renderTokens = function renderTokens(
    tokens,
    context,
    partials,
    originalTemplate,
    config
  ) {
    var buffer = "";

    var token, symbol, value;
    for (var i = 0, numTokens = tokens.length; i < numTokens; ++i) {
      value = undefined;
      token = tokens[i];
      symbol = token[0];

      if (symbol === "#")
        value = this.renderSection(
          token,
          context,
          partials,
          originalTemplate,
          config
        );
      else if (symbol === "^")
        value = this.renderInverted(
          token,
          context,
          partials,
          originalTemplate,
          config
        );
      else if (symbol === ">")
        value = this.renderPartial(token, context, partials, config);
      else if (symbol === "&") value = this.unescapedValue(token, context);
      else if (symbol === "name")
        value = this.escapedValue(token, context, config);
      else if (symbol === "text") value = this.rawValue(token);

      if (value !== undefined) buffer += value;
    }

    return buffer;
  };

  Writer.prototype.renderSection = function renderSection(
    token,
    context,
    partials,
    originalTemplate,
    config
  ) {
    var self = this;
    var buffer = "";
    var value = context.lookup(token[1]);

    // This function is used to render an arbitrary template
    // in the current context by higher-order sections.
    function subRender(template) {
      return self.render(template, context, partials, config);
    }

    if (!value) return;

    if (isArray(value)) {
      for (var j = 0, valueLength = value.length; j < valueLength; ++j) {
        buffer += this.renderTokens(
          token[4],
          context.push(value[j]),
          partials,
          originalTemplate,
          config
        );
      }
    } else if (
      typeof value === "object" ||
      typeof value === "string" ||
      typeof value === "number"
    ) {
      buffer += this.renderTokens(
        token[4],
        context.push(value),
        partials,
        originalTemplate,
        config
      );
    } else if (isFunction(value)) {
      if (typeof originalTemplate !== "string")
        throw new Error(
          "Cannot use higher-order sections without the original template"
        );

      // Extract the portion of the original template that the section contains.
      value = value.call(
        context.view,
        originalTemplate.slice(token[3], token[5]),
        subRender
      );

      if (value != null) buffer += value;
    } else {
      buffer += this.renderTokens(
        token[4],
        context,
        partials,
        originalTemplate,
        config
      );
    }
    return buffer;
  };

  Writer.prototype.renderInverted = function renderInverted(
    token,
    context,
    partials,
    originalTemplate,
    config
  ) {
    var value = context.lookup(token[1]);

    // Use JavaScript's definition of falsy. Include empty arrays.
    // See https://github.com/janl/mustache.js/issues/186
    if (!value || (isArray(value) && value.length === 0))
      return this.renderTokens(
        token[4],
        context,
        partials,
        originalTemplate,
        config
      );
  };

  Writer.prototype.indentPartial = function indentPartial(
    partial,
    indentation,
    lineHasNonSpace
  ) {
    var filteredIndentation = indentation.replace(/[^ \t]/g, "");
    var partialByNl = partial.split("\n");
    for (var i = 0; i < partialByNl.length; i++) {
      if (partialByNl[i].length && (i > 0 || !lineHasNonSpace)) {
        partialByNl[i] = filteredIndentation + partialByNl[i];
      }
    }
    return partialByNl.join("\n");
  };

  Writer.prototype.renderPartial = function renderPartial(
    token,
    context,
    partials,
    config
  ) {
    if (!partials) return;
    var tags = this.getConfigTags(config);

    var value = isFunction(partials) ? partials(token[1]) : partials[token[1]];
    if (value != null) {
      var lineHasNonSpace = token[6];
      var tagIndex = token[5];
      var indentation = token[4];
      var indentedValue = value;
      if (tagIndex == 0 && indentation) {
        indentedValue = this.indentPartial(value, indentation, lineHasNonSpace);
      }
      var tokens = this.parse(indentedValue, tags);
      return this.renderTokens(
        tokens,
        context,
        partials,
        indentedValue,
        config
      );
    }
  };

  Writer.prototype.unescapedValue = function unescapedValue(token, context) {
    var value = context.lookup(token[1]);
    if (value != null) return value;
  };

  Writer.prototype.escapedValue = function escapedValue(
    token,
    context,
    config
  ) {
    var escape = this.getConfigEscape(config) || mustache.escape;
    var value = context.lookup(token[1]);
    if (value != null)
      return typeof value === "number" && escape === mustache.escape
        ? String(value)
        : escape(value);
  };

  Writer.prototype.rawValue = function rawValue(token) {
    return token[1];
  };

  Writer.prototype.getConfigTags = function getConfigTags(config) {
    if (isArray(config)) {
      return config;
    } else if (config && typeof config === "object") {
      return config.tags;
    } else {
      return undefined;
    }
  };

  Writer.prototype.getConfigEscape = function getConfigEscape(config) {
    if (config && typeof config === "object" && !isArray(config)) {
      return config.escape;
    } else {
      return undefined;
    }
  };

  var mustache = {
    name: "mustache.js",
    version: "4.2.0",
    tags: ["{{", "}}"],
    clearCache: undefined,
    escape: undefined,
    parse: undefined,
    render: undefined,
    Scanner: undefined,
    Context: undefined,
    Writer: undefined,
    /**
     * Allows a user to override the default caching strategy, by providing an
     * object with set, get and clear methods. This can also be used to disable
     * the cache by setting it to the literal `undefined`.
     */
    set templateCache(cache) {
      defaultWriter.templateCache = cache;
    },
    /**
     * Gets the default or overridden caching object from the default writer.
     */
    get templateCache() {
      return defaultWriter.templateCache;
    },
  };

  // All high-level mustache.* functions use this writer.
  var defaultWriter = new Writer();

  /**
   * Clears all cached templates in the default writer.
   */
  mustache.clearCache = function clearCache() {
    return defaultWriter.clearCache();
  };

  /**
   * Parses and caches the given template in the default writer and returns the
   * array of tokens it contains. Doing this ahead of time avoids the need to
   * parse templates on the fly as they are rendered.
   */
  mustache.parse = function parse(template, tags) {
    return defaultWriter.parse(template, tags);
  };

  /**
   * Renders the `template` with the given `view`, `partials`, and `config`
   * using the default writer.
   */
  mustache.render = function render(template, view, partials, config) {
    if (typeof template !== "string") {
      throw new TypeError(
        'Invalid template! Template should be a "string" ' +
          'but "' +
          typeStr(template) +
          '" was given as the first ' +
          "argument for mustache#render(template, view, partials)"
      );
    }

    return defaultWriter.render(template, view, partials, config);
  };

  // Export the escaping function so that the user may override it.
  // See https://github.com/janl/mustache.js/issues/244
  mustache.escape = escapeHtml;

  // Export these mainly for testing, but also for advanced usage.
  mustache.Scanner = Scanner;
  mustache.Context = Context;
  mustache.Writer = Writer;

  return mustache;
});

const app = {
  context: (() => {
    // create strategy pattern
    const _context = {
      id: window.location.href.slice(-5),
      server_src: "https://upload.pictureserver.net/static/2024/",
      language:
        document.querySelector("select[name='lang']")?.value || "english",
      seller:
        document.querySelector("select[name='seller']")?.value || "Beliani UK",
      isLanding: window.location.href.includes("shop_content"),
      languageToSlug: {
        polish: "pl",
        portugal: "pt",
        spanish: "es",
        german: "chde",
        germanDE: "de",
        Hungarian: "hu",
        finnish: "fi",
        french: "fr",
        czech: "cz",
        slovak: "sk",
        danish: "dk",
        italian: "it",
        swedish: "se",
        english: "uk",
        norsk: "no",
        dutch: "nl",
      },
      sellerToOrigin: {
        Beliani: "https://www.beliani.ch/",
        "Beliani UK": "https://www.beliani.co.uk/",
        "Beliani DE": "https://www.beliani.de/",
        "Beliani FR": "https://www.beliani.fr/",
        "Beliani AT": "https://www.beliani.at/",
        "Beliani SP": "https://www.beliani.es/",
        "Beliani PL": "https://www.beliani.pl/",
        "Beliani NL": "https://www.beliani.nl/",
        "Beliani PT": "https://www.beliani.pt/",
        "Beliani IT": "https://www.beliani.it/",
        "Beliani SE": "https://www.beliani.se/",
        "Beliani HU": "https://www.beliani.hu/",
        "Beliani DK": "https://www.beliani.dk/",
        "Beliani CZ": "https://www.beliani.cz/",
        "Beliani FI": "https://www.beliani.fi/",
        "Beliani NO": "https://www.beliani.no/",
        "Beliani SK": "https://www.beliani.sk/",
        "Beliani BE": "https://www.beliani.be/",
      },
      sellerToSlug: {
        Beliani: "chde",
        "Beliani UK": "uk",
        "Beliani DE": "de",
        "Beliani FR": "fr",
        "Beliani AT": "at",
        "Beliani SP": "es",
        "Beliani PL": "pl",
        "Beliani NL": "nl",
        "Beliani PT": "pt",
        "Beliani IT": "it",
        "Beliani SE": "se",
        "Beliani HU": "hu",
        "Beliani DK": "dk",
        "Beliani CZ": "cz",
        "Beliani FI": "fi",
        "Beliani NO": "no",
        "Beliani SK": "sk",
        "Beliani BE": "be",
      },
      languageAttributeToSeller: {
        "html[czech]": "Beliani CZ",
        "html[danish]": "Beliani DK",
        "html[dutch]": "Beliani NL",
        "html[english]": "Beliani UK",
        "html[finnish]": "Beliani FI",
        "html[french]": "Beliani FR",
        "html[german]": "Beliani DE",
        "html[germanDE]": "Beliani",
        "html[Hungarian]": "Beliani HU",
        "html[italian]": "Beliani IT",
        "html[norsk]": "Beliani NO",
        "html[polish]": "Beliani PL",
        "html[portugal]": "Beliani PT",
        "html[slovak]": "Beliani SK",
        "html[spanish]": "Beliani SP",
        "html[swedish]": "Beliani SE",
      },
      languageAttributeToSlug: {
        "html[czech]": "cz",
        "html[danish]": "dk",
        "html[dutch]": "nl",
        "html[english]": "uk",
        "html[finnish]": "fi",
        "html[french]": "fr",
        "html[german]": "de",
        "html[germanDE]": "chde",
        "html[Hungarian]": "hu",
        "html[italian]": "it",
        "html[norsk]": "no",
        "html[polish]": "pl",
        "html[portugal]": "pt",
        "html[slovak]": "sk",
        "html[spanish]": "es",
        "html[swedish]": "se",
      },
    };

    const proxyLanguageToSlug = new Proxy(_context.languageAttributeToSlug, {
      get(target, prop, receiver) {
        if (prop in target) {
          return target[prop];
        } else {
          return target["html[english]"];
        }
      },
    });

    const proxyLanguageToSeller = new Proxy(
      _context.languageAttributeToSeller,
      {
        get(target, prop, receiver) {
          if (prop in target) {
            return target[prop];
          } else {
            return target["html[english]"];
          }
        },
      }
    );

    if (_context.isLanding) {
      const textareas = [...(document.querySelectorAll("textarea") || [])]
        .filter((item) => item.getAttribute("id").startsWith("trnewvalue"))
        .map((item) => ({
          node: item,
          slug: proxyLanguageToSlug[item.getAttribute("name")],
          seller: proxyLanguageToSeller[item.getAttribute("name")],
        }));

      textareas.forEach((item) => {
        const btn = document.createElement("button");
        btn.type = "button";
        btn.style.fontSize = "11px";
        btn.textContent = "Fulfill template";
        btn.addEventListener("click", () => {
          app.fulfillTemplate({
            slug: item.slug,
            template: item.node.value,
            seller: item.seller,
          });
        });
        item.node.parentNode.append(btn);
      });

      return {
        isLanding: _context.isLanding,
        textareas: textareas,
      };
    }

    return {
      ..._context,
      id: _context.id,
      slug: _context.languageToSlug[_context.language],
      origin: _context.sellerToOrigin[_context.seller],
      seller: _context.seller,
      tracking_url:
        "?utm_source=newsletter&amp;utm_medium=email&amp;utm_campaign=" +
        _context.id,
    };
  })(),
  fulfillTemplate: (data) => {
    setTimeout(() => {
      try {
        const text_slug = app.getDataBy({
          by1: "slug",
          target: app.context.slug,
          data: data.translations,
        });

        const categories_slug = app.getDataBy({
          by1: "slug",
          target: app.context.slug,
          data: data.categories,
        });

        const images_slug = app.getDataBy({
          by1: "slug",
          target: app.context.slug,
          data: data.images,
        });

        if (app.context.isLanding) {
          textareas.forEach((item) => app.swapLP(item), {
            text_slug,
            categories_slug,
            images_slug,
          });
        } else {
          app.swapNS({ text_slug, categories_slug, images_slug });
        }
      } catch (error) {
        new Notification(error.message || "Unexpected error happend.");
      }
    }, 1000);
  },
  getDataBy: ({ by1, by2, target, data }) => {
    let result = [];
    for (const element of data) {
      if (by2) {
        if (element[by1][by2].toLowerCase() === target.toLowerCase()) {
          result.push(element);
        }
      } else {
        if (element[by1].toLowerCase() === target.toLowerCase()) {
          result.push(element);
        }
      }
    }
    return result;
  },
  fetchProducts: async (ids, { seller }) => {
    // getProductName - return product name
    // getShopAliases - returns aliases for every shop
    // getSlavesForMasterId - return slaves for master id
    // getPrice - return price for passed id

    const apiRoutes = {
      getProductName: (master_id) =>
        `https://www.prologistics.info/api/condensedSA/get/?id=${master_id}&block=article_name`,
      getSlavesForMasterId: (master_id) =>
        `https://www.prologistics.info/api/condensedList/getList?saved_id=${master_id}`,
      getPrice: (slave_id) =>
        `https://www.prologistics.info/api/condensedSA/getSlave/?id=${slave_id}&block=saved_params`,
      getShopAliases: (master_id) =>
        `https://www.prologistics.info/api/condensedSA/get/?id=${master_id}&block=ShopSAAlias`,
      getPriceAndIsActive: (slave_id) =>
        `https://www.prologistics.info/api/condensedSA/getSlave/?id=${slave_id}&block=buttons`,
    };

    async function parse_response(responses, cbs) {
      const responses_json = [];

      for (let index = 0; index < responses.length; index++) {
        const response = responses[index];
        if (response.status === "fulfilled") {
          if (response.value.ok) {
            const response_json = await response.value.json();
            responses_json.push(
              Array.isArray(cbs)
                ? cbs[index](response_json)
                : cbs(response_json)
            );
          } else {
            console.log(
              "Response value is not ok while parsing slaves response."
            );
          }
        }

        if (response.status === "rejected") {
          console.log("Rejected 2");
        }
      }

      return responses_json;
    }

    async function parse_response_prices(slave_responses) {
      const json_data = [];
      for (const slave_response of slave_responses) {
        if (slave_response.status === "fulfilled") {
          if (slave_response.value.ok) {
            const response_json = await slave_response.value.json();
            json_data.push(response_json.sa);
          } else {
            json_data.push(slave_response.value);
          }
        }

        if (slave_response.status === "rejected") {
          json_data.push(slave_response.value);
        }
      }

      return json_data;
    }

    async function getProductData(product) {
      // 1.1 Get names for each id.
      // 1.2 Get slaves id's
      // 1.3 Get shop aliases
      const parsed_response_slaves = await parse_response(
        await Promise.allSettled([
          fetch(apiRoutes.getProductName(product.main_id)),
          fetch(apiRoutes.getSlavesForMasterId(product.main_id)),
        ]),
        [
          // 2.1 Array of callbacks.
          // 2.2 Call callback and for each of:
          // 1.1 Get names for each id. -> (response) => response.sa.article_name

          // 1.2 Get slaves id's -> response.saCollection.list.filter((item) => {
          //   if (item.master_sa === product.main_id || item.master_sa === "0") {
          //     return true;
          //   }
          //   return false;
          // })
          (response) => response.sa.article_name,
          (response) => response.saCollection.list,
        ]
      );
      const [name, slaves_ids] = parsed_response_slaves;

      // ENTER models slave.js
      const slaves_prices = await parse_response_prices(
        await Promise.allSettled(
          // Fetch price only for Seller
          slaves_ids
            .filter(
              (slave) =>
                slave.username === seller || slave.username === "Beliani"
            )
            .map((slave) => fetch(apiRoutes.getPriceAndIsActive(slave.id)))
        )
      );
      // EXIT models getPriceAndIsActive.js

      return slaves_prices.map((item) => {
        return {
          ...item,
          article_name: name,
        };
      });
    }

    // Iterate over each main_id and create Promise.
    const ids_response = await Promise.allSettled(
      ids.map((product) => getProductData(product))
    );

    return ids_response.map((item) => item.value).flat();
  },
  getAliases: (products_slug, products) => {
    const aliases = [];
    products_slug.forEach((item) => {
      for (const element of products) {
        if (Number(item.saved_params.master_sa) === element.id) {
          aliases.push({
            aliases: element.ShopSAAlias,
            id: element.id,
          });
        }
      }
    });
    return aliases;
  },
  format(price, seller) {
    const slugFromSeller = app.context.sellerToSlug[seller].toUpperCase();
    const formatPrice = {
      DE: (price) => {
        price = price.replace(".00", ",00");
        price = price.replace(".99", ",99");

        if (price.length === 8) {
          price = price.split("").toSpliced(2, 0, ".").join("");
        }

        if (price.length === 7) {
          price = price.split("").toSpliced(1, 0, ".").join("");
        }

        return price;
      },
      CHDE: (price) => {
        if (price.length === 8) {
          price = price.split("").toSpliced(2, 0, "'").join("");
        }

        if (price.length === 7) {
          price = price.split("").toSpliced(1, 0, "'").join("");
        }

        return price;
      },
      AT: (price) => {
        price = price.replace(".00", ",00");
        price = price.replace(".99", ",99");

        if (price.length === 8) {
          price = price.split("").toSpliced(2, 0, ".").join("");
        }

        if (price.length === 7) {
          price = price.split("").toSpliced(1, 0, ".").join("");
        }

        return price;
      },
      FR: (price) => {
        price = price.replace(".00", ",00");
        price = price.replace(".99", ",99");

        if (price.length === 8) {
          price = price.split("").toSpliced(2, 0, " ").join("");
        }

        if (price.length === 7) {
          price = price.split("").toSpliced(1, 0, " ").join("");
        }

        return price;
      },
      BE: (price) => {
        price = price.replace(".00", ",00");
        price = price.replace(".99", ",99");

        if (price.length === 8) {
          price = price.split("").toSpliced(2, 0, ".").join("");
        }

        if (price.length === 7) {
          price = price.split("").toSpliced(1, 0, ".").join("");
        }

        return price;
      },
      IT: (price) => {
        price = price.replace(".00", ",00");
        price = price.replace(".99", ",99");

        if (price.length === 8) {
          price = price.split("").toSpliced(2, 0, ".").join("");
        }

        if (price.length === 7) {
          price = price.split("").toSpliced(1, 0, ".").join("");
        }

        return price;
      },
      UK: (price) => {
        if (price.length === 8) {
          price = price.split("").toSpliced(2, 0, ",").join("");
        }

        if (price.length === 7) {
          price = price.split("").toSpliced(1, 0, ",").join("");
        }

        return price;
      },
      ES: (price) => {
        price = price.replace(".00", ",00");
        price = price.replace(".99", ",99");

        if (price.length === 8) {
          price = price.split("").toSpliced(2, 0, ".").join("");
        }

        if (price.length === 7) {
          price = price.split("").toSpliced(1, 0, ".").join("");
        }

        return price;
      },
      PT: (price) => {
        price = price.replace(".00", ",00");
        price = price.replace(".99", ",99");

        if (price.length === 8) {
          price = price.split("").toSpliced(2, 0, ".").join("");
        }

        if (price.length === 7) {
          price = price.split("").toSpliced(1, 0, ".").join("");
        }

        return price;
      },
      PL: (price) => {
        price = price.replace(".00", "");
        price = price.replace(".99", "");

        if (price.length === 5) {
          price = price.split("").toSpliced(2, 0, " ").join("");
        }

        if (price.length === 4) {
          price = price.split("").toSpliced(1, 0, " ").join("");
        }

        return price;
      },
      HU: (price) => {
        price = price.replace(".00", "");
        price = price.replace(".99", "");

        if (price.length === 7) {
          price = price
            .split("")
            .toSpliced(1, 0, " ")
            .toSpliced(5, 0, " ")
            .join("");
        }

        if (price.length === 6) {
          price = price.split("").toSpliced(3, 0, " ").join("");
        }

        if (price.length === 5) {
          price = price.split("").toSpliced(2, 0, " ").join("");
        }

        if (price.length === 4) {
          price = price.split("").toSpliced(1, 0, " ").join("");
        }

        return price;
      },
      NL: (price) => {
        price = price.replace(".00", ",00");
        price = price.replace(".99", ",99");

        if (price.length === 8) {
          price = price.split("").toSpliced(2, 0, ".").join("");
        }

        if (price.length === 7) {
          price = price.split("").toSpliced(1, 0, ".").join("");
        }

        return price;
      },
      SE: (price) => {
        price = price.replace(".00", "");

        if (price.length === 5) {
          price = price.split("").toSpliced(2, 0, " ").join("");
        }

        if (price.length === 4) {
          price = price.split("").toSpliced(1, 0, " ").join("");
        }

        return price;
      },
      DK: (price) => {
        price = price.replace(".00", "");

        if (price.length === 5) {
          price = price.split("").toSpliced(2, 0, ".").join("");
        }

        if (price.length === 4) {
          price = price.split("").toSpliced(1, 0, ".").join("");
        }

        return price;
      },
      CZ: (price) => {
        price = price.replace(".00", "");

        if (price.length === 6) {
          price = price.split("").toSpliced(3, 0, " ").join("");
        }

        if (price.length === 5) {
          price = price.split("").toSpliced(2, 0, " ").join("");
        }

        if (price.length === 4) {
          price = price.split("").toSpliced(1, 0, " ").join("");
        }

        return price;
      },
      FI: (price) => {
        price = price.replace(".00", ",00");
        price = price.replace(".99", ",99");

        if (price.length === 8) {
          price = price.split("").toSpliced(2, 0, " ").join("");
        }

        if (price.length === 7) {
          price = price.split("").toSpliced(1, 0, " ").join("");
        }

        return price;
      },
      NO: (price) => {
        price = price.replace(".00", "");

        if (price.length === 5) {
          price = price.split("").toSpliced(2, 0, ".").join("");
        }

        if (price.length === 4) {
          price = price.split("").toSpliced(1, 0, ".").join("");
        }

        return price;
      },
      SK: (price) => {
        price = price.replace(".00", ",00");
        price = price.replace(".99", ",99");

        if (price.length === 8) {
          price = price.split("").toSpliced(2, 0, " ").join("");
        }

        if (price.length === 7) {
          price = price.split("").toSpliced(1, 0, " ").join("");
        }

        return price;
      },
    };
    const currencies = {
      euro: "€",
      swissFranc: "Fr.",
      poundSterling: "£",
      hungarianForint: "Ft",
      swedishKrona: ":-",
      danishKrona: "kr.",
      czechKrona: "Kč",
      norwegianKrone: ",-",
      polandZloty: ",-",
    };
    const sellerToFormat = {
      Beliani: (price) => {
        return formatPrice[slugFromSeller](price) + " " + currencies.swissFranc;
      },
      "Beliani UK": (price) => {
        return currencies.poundSterling + formatPrice[slugFromSeller](price);
      },
      "Beliani DE": (price) => {
        return formatPrice[slugFromSeller](price) + " " + currencies.euro;
      },
      "Beliani FR": (price) => {
        return formatPrice[slugFromSeller](price) + " " + currencies.euro;
      },
      "Beliani AT": (price) => {
        return formatPrice[slugFromSeller](price) + " " + currencies.euro;
      },
      "Beliani SP": (price) => {
        return formatPrice[slugFromSeller](price) + " " + currencies.euro;
      },
      "Beliani PL": (price) => {
        return formatPrice[slugFromSeller](price) + currencies.polandZloty;
      },
      "Beliani NL": (price) => {
        return currencies.euro + " " + formatPrice[slugFromSeller](price);
      },
      "Beliani PT": (price) => {
        return formatPrice[slugFromSeller](price) + " " + currencies.euro;
      },
      "Beliani IT": (price) => {
        return formatPrice[slugFromSeller](price) + " " + currencies.euro;
      },
      "Beliani SE": (price) => {
        return formatPrice[slugFromSeller](price) + currencies.swedishKrona;
      },
      "Beliani HU": (price) => {
        return (
          formatPrice[slugFromSeller](price) + " " + currencies.hungarianForint
        );
      },
      "Beliani DK": (price) => {
        return (
          formatPrice[slugFromSeller](price) + " " + currencies.danishKrona
        );
      },
      "Beliani CZ": (price) => {
        return formatPrice[slugFromSeller](price) + " " + currencies.czechKrona;
      },
      "Beliani FI": (price) => {
        return formatPrice[slugFromSeller](price) + " " + currencies.euro;
      },
      "Beliani NO": (price) => {
        return formatPrice[slugFromSeller](price) + currencies.norwegianKrone;
      },
      "Beliani SK": (price) => {
        return formatPrice[slugFromSeller](price) + " " + currencies.euro;
      },
      "Beliani BE": (price) => {
        return formatPrice[slugFromSeller](price) + " " + currencies.euro;
      },
    };
    return sellerToFormat[seller](price);
  },
  swapNodesWithAttribute: ({ attribute, doc, data }) => {
    const type = attribute.split("-").at(-1);
    for (const node of doc.querySelectorAll("[" + attribute + "]")) {
      const template = node.getAttribute(attribute);
      const data_to_swap = {
        ...data,
        origin: app.context.origin,
        id: app.context.id,
        server_src: app.context.server_src,
        tracking_url: app.context.tracking_url,
        slug: app.context.slug,
      };
      const content = Mustache.render(template, data_to_swap);
      node[type] = content;
    }
    return doc;
  },
  downloadJSON: ({ data, name }) => {
    const stringifuProducts = JSON.stringify(data);
    const blob = new Blob([stringifuProducts], { type: "application/json" });
    const urlBlob = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.download = name;
    a.href = urlBlob;
    a.click();
    a.remove();
  },
  isActive: (products) => {
    let isInactiveProducts = false;
    const inActiveProducts = [];
    for (const product of products) {
      if (product.data.inactive === "1") {
        inActiveProducts.push(product);
      }
    }
    return {
      isInactiveProducts,
      inActiveProducts,
    };
  },
  swapLP: (
    { node, slug, seller },
    { text_slug, categories_slug, images_slug }
  ) => {
    setTimeout(async () => {
      const doc = new DOMParser().parseFromString(node.value, "text/html");

      const newsletterProducts = {};
      let main_ids = doc
        .querySelector("[data-products]")
        ?.getAttribute("data-products");
      if (main_ids) {
        const array_of_ids = main_ids
          .split(",")
          .map((item) => ({ main_id: item }));
        const products = await app.fetchProducts(array_of_ids, { seller });
        // Check active status
        const { inActiveProducts, isInactiveProducts } = app.isActive(products);
        if (isInactiveProducts) {
          alert("Inactive products found.");
          app.downloadJSON({
            data: inActiveProducts,
            name: "inactive_products.json",
          });
          return;
        }
        const products_slug = app.getDataBy({
          by1: "saved_params",
          by2: "username",
          target: app.context.seller,
          data: products,
        });

        // SORT elements relative to whan user has been provided
        const sortedProductsByUserArr = [];
        for (const master_sa of array_of_ids) {
          for (const elem of products_slug) {
            if (elem.saved_params.master_sa === master_sa.main_id) {
              sortedProductsByUserArr.push(elem);
            }
          }
        }

        const aliases = app.getAliases(sortedProductsByUserArr, products);

        for (const [idx, elem] of sortedProductsByUserArr.entries()) {
          const lowPrice = elem.saved_params.ShopPrice;
          const highPrice = elem.saved_params.ShopHPrice;
          const href =
            aliases[idx].aliases[app.context.language].value + ".html";
          newsletterProducts[`product_${idx + 1}`] = {
            name: elem.article_name,
            href: href,
            lowPrice: lowPrice ? app.format(lowPrice, app.context.seller) : "",
            highPrice: highPrice
              ? app.format(highPrice, app.context.seller)
              : "",
          };
        }
      }

      const swappedTextContentDocument = app.swapNodesWithAttribute({
        attribute: "data-property-textContent",
        doc: doc,
        data: {
          ...text_slug[0],
          ...categories_slug[0],
          ...newsletterProducts,
        },
      });
      const swappedSrcDocument = app.swapNodesWithAttribute({
        attribute: "data-property-src",
        doc: swappedTextContentDocument,
        data: {
          ...images_slug[0],
          ...categories_slug[0],
        },
      });
      const swappedHrefDocument = app.swapNodesWithAttribute({
        attribute: "data-property-href",
        doc: swappedSrcDocument,
        data: {
          ...categories_slug[0],
          ...newsletterProducts,
        },
      });

      doc.body.innerHTML = swappedHrefDocument.body.innerHTML;
      textarea.value = doc.documentElement.outerHTML;
      const update = document.querySelector("input[value='Update body']");
      update.click();
    }, 1000);
  },
  swapNS: ({ text_slug, categories_slug, images_slug }) => {
    const source = document.querySelector("#cke_19");
    setTimeout(async () => {
      source.click();
      const textarea = document.querySelector("#cke_1_contents > textarea");
      const doc = new DOMParser().parseFromString(textarea.value, "text/html");

      const newsletterProducts = {};
      let main_ids = doc
        .querySelector("[data-products]")
        ?.getAttribute("data-products");
      if (main_ids) {
        const array_of_ids = main_ids
          .split(",")
          .map((item) => ({ main_id: item }));
        const products = await app.fetchProducts(array_of_ids, {
          seller: app.context.seller,
        });
        // Check active status
        const { inActiveProducts, isInactiveProducts } = app.isActive(products);
        if (isInactiveProducts) {
          alert("Inactive products found.");
          app.downloadJSON({
            data: inActiveProducts,
            name: "inactive_products.json",
          });
          return;
        }
        const products_slug = app.getDataBy({
          by1: "saved_params",
          by2: "username",
          target: app.context.seller,
          data: products,
        });

        // SORT elements relative to whan user has been provided
        const sortedProductsByUserArr = [];
        for (const master_sa of array_of_ids) {
          for (const elem of products_slug) {
            if (elem.saved_params.master_sa === master_sa.main_id) {
              sortedProductsByUserArr.push(elem);
            }
          }
        }

        const aliases = app.getAliases(sortedProductsByUserArr, products);

        for (const [idx, elem] of sortedProductsByUserArr.entries()) {
          const lowPrice = elem.saved_params.ShopPrice;
          const highPrice = elem.saved_params.ShopHPrice;
          const href =
            aliases[idx].aliases[app.context.language].value + ".html";
          newsletterProducts[`product_${idx + 1}`] = {
            name: elem.article_name,
            href: href,
            lowPrice: lowPrice ? app.format(lowPrice, app.context.seller) : "",
            highPrice: highPrice
              ? app.format(highPrice, app.context.seller)
              : "",
          };
        }
      }

      const swappedTextContentDocument = app.swapNodesWithAttribute({
        attribute: "data-property-textContent",
        doc: doc,
        data: {
          ...text_slug[0],
          ...categories_slug[0],
          ...newsletterProducts,
        },
      });
      const swappedSrcDocument = app.swapNodesWithAttribute({
        attribute: "data-property-src",
        doc: swappedTextContentDocument,
        data: {
          ...images_slug[0],
          ...categories_slug[0],
        },
      });
      const swappedHrefDocument = app.swapNodesWithAttribute({
        attribute: "data-property-href",
        doc: swappedSrcDocument,
        data: {
          ...categories_slug[0],
          ...newsletterProducts,
        },
      });

      doc.body.innerHTML = swappedHrefDocument.body.innerHTML;
      textarea.value = doc.documentElement.outerHTML;
      const update = document.querySelector("input[value='Update body']");
      update.click();
    }, 1000);
  },
};

function createFulfillTemplateButton() {
  const btn = document.createElement("button");
  btn.style.fontSize = "11px";
  btn.type = "button";
  btn.textContent = "Fulfill template";
  btn.addEventListener("click", () => {
    const data = requestData();
    if (!data) {
      new Notification("Pls, provide all data.");
    } else {
      app.fulfillTemplate(data);
    }
  });
  const updateBtn = document.querySelector("[name=update_body");
  if (updateBtn) {
    updateBtn.parentNode.append(btn);
  } else {
    new Notification("Too long loading. Try later.");
  }
}

function requestData() {
  const data = {
    translations: [],
    categories: [],
    images: [],
  };
  for (const key of Object.keys(data)) {
    const raw_data = prompt(`Provide data for ${key}: `);
    if (!raw_data) return;
    try {
      const json = JSON.parse(raw_data);
      if (Array.isArray(json)) {
        data[key] = json;
      } else {
        new Notification("Data is not valid. Only Arrays accepted.");
        return;
      }
    } catch (error) {
      new Notification("JSON is not valid.");
      return;
    }
  }

  return isAllDataProvided(data) ? data : null;
}

function isAllDataProvided(data) {
  let isCorrect = true;
  for (const item of Object.values(data)) {
    if (item.length === 0) {
      isCorrect = false;
    }
  }

  return isCorrect;
}

setTimeout(() => {
  createFulfillTemplateButton();
}, 2000);
