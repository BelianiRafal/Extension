function isActive(products) {
    let isInactiveProducts = false
    const inActiveProducts = []
    for (const product of products) {
        if (product.data.inactive === "1") {
            inActiveProducts.push(product)
        }
    }
    return {
        isInactiveProducts,
        inActiveProducts
    }
}