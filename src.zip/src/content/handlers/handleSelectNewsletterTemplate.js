function handleSelectTemplate(html) {
  const payload_campaign = {
    campaign_id: DEFAULT_VARIABLES.id,
    body: html,
  };
  handleButtonBodyUpdate(payload_campaign);
}
