const slave = {
  id: "162672",
  master_sa: "150033",
  offer_id: "219760",
  username: "Beliani IT",
  url: "beliani.it",
  auction_name: "Beliani.it Konsolentisch CARCASSONNE Spiegeleffekt CH",
  multi: "-1",
};
